========================================================
Using setuptools to package and distribute your project
========================================================

``setuptools`` offers a variety of functionalities that make it easy to
build and distribute your python package. Here we provide an overview on
the commonly used ones.


